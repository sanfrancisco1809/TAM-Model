document.addEventListener('DOMContentLoaded', function() {
    initializeGame();
    document.getElementById('reset-game').addEventListener('click', initializeGame);
});

function initializeGame() {
    document.getElementById('statements').innerHTML = '';
    document.getElementById('pu').innerHTML = '<h2>Perceived Usefulness (PU)</h2>';
    document.getElementById('peou').innerHTML = '<h2>Perceived Ease of Use (PEOU)</h2>';
    document.getElementById('score').textContent = '0';

    const statementsData = [
        { text: "Improves job performance.", category: "pu" },
        { text: "Enhances productivity.", category: "pu" },
        { text: "Increases job effectiveness.", category: "pu" },
        { text: "Useful in completing job tasks.", category: "pu" },
        { text: "Saves time in task completion.", category: "pu" },
        { text: "Easy to learn to use.", category: "peou" },
        { text: "Simple to operate.", category: "peou" },
        { text: "User-friendly interface.", category: "peou" },
        { text: "Easy to become skillful at using it.", category: "peou" },
        { text: "Requires minimal effort to use.", category: "peou" }
    ];

    statementsData.forEach((item, index) => createStatement(item, index));
    setupCategories();
}

function createStatement(item, index) {
    const statementsArea = document.getElementById('statements');
    const statementDiv = document.createElement('div');
    statementDiv.classList.add('statement');
    statementDiv.setAttribute('draggable', true);
    statementDiv.setAttribute('id', 'statement-' + index);
    statementDiv.textContent = item.text;
    statementDiv.dataset.category = item.category;
    statementDiv.addEventListener('dragstart', drag);
    statementsArea.appendChild(statementDiv);
}

function setupCategories() {
    document.querySelectorAll('.category').forEach(category => {
        category.addEventListener('dragover', allowDrop);
        category.addEventListener('drop', drop);
    });
}

function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    var statement = document.getElementById(data);
    var target = ev.target.closest('.category');

    if (target && !statement.classList.contains('dropped')) {
        target.appendChild(statement);
        statement.classList.add('dropped');
        updateScore();
    }
}

function updateScore() {
    const statements = document.querySelectorAll('.statement.dropped');
    let score = 0;
    statements.forEach(statement => {
        if (statement.dataset.category === statement.parentNode.id) {
            score++;
            statement.style.border = "2px solid green"; // Correct
        } else {
            statement.style.border = "2px solid red"; // Incorrect
        }
    });
    document.getElementById('score').textContent = `${score}`;
}


function resetGameState() {
    document.querySelectorAll('.statement').forEach(statement => {
        statement.classList.remove('dropped');
        document.getElementById('statements').appendChild(statement);
    });
    updateScore();
}
